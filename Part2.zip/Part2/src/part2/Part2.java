/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package part2;

import javax.swing.JOptionPane;
//
/**
 *
 * @author lab_services_student
 */
public class Part2 {

    private static int totalHours = 0;
    private static int taskCount = 0;
    private static final int MAXIMUM_TASK_DESCRIPTION_LENGTH = 50;
    
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
    
    public Part2(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskCount++;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
        this.taskStatus = taskStatus;
        totalHours += taskDuration;
    }
    
    public boolean checkTaskDescription() {
        return taskDescription.length() <= MAX_DESCRIPTION_LENGTH;
    }
    
    public String createTaskID() {
        String firstLetters = taskName.substring(0, 2);
        String lastLetters = developerDetails.substring(developerDetails.length() - 3);
        return firstLetters.toUpperCase() + ":" + taskNumber + ":" + lastLetters.toUpperCase();
    }
    
    public String printTaskDetails() {
        return "Task Status: " + taskStatus +
               "\nDeveloper Details: " + developerDetails +
               "\nTask Number: " + taskNumber +
               "\nTask Name: " + taskName +
               "\nTask Description: " + taskDescription +
               "\nTask ID: " + taskID +
               "\nDuration: " + taskDuration + " hours";
    }
    
    public static int returnTotalHours() {
        return totalHours;
    }
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban"); //www.javatpoint.com. (n.d.). Java JOptionPane - javatpoint.  Available at: https://www.javatpoint.com/java-joptionpane#:~:text=The%20JOptionPane%20class%20is%20used%20to%20provide%20standard 

‌
        
        int choice;
        do {
            choice = Integer.parseInt(JOptionPane.showInputDialog("Menu:\n1) Add tasks\n2) Show report\n3) Quit"));
            
            switch (choice) {////Stack Overflow. (n.d.). Java Switch Statement. Available at: https://stackoverflow.com/questions/17814926/java-switch-statement.

                case 1:
                    int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks:"));
                    for (int i = 0; i < numTasks; i++) {//www.homeandlearn.co.uk. (n.d.). java for complete beginners - variables: the int type. @: https://www.homeandlearn.co.uk/java/java_int_variables.html 

‌
                        String taskName = JOptionPane.showInputDialog("Enter the task name:");
                        String taskDescription = JOptionPane.showInputDialog("Enter the task description:");
                        String developerDetails = JOptionPane.showInputDialog("Enter the developer details:");
                        int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the task duration (in hours):"));
                        String taskStatus = JOptionPane.showInputDialog("Enter the task status (To Do / Done / Doing):");
                        
                        Part2 task = new Part2(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
                        
                        if (task.checkTaskDescription()) {
                            JOptionPane.showMessageDialog(null, "Task successfully captured\n\n" + task.printTaskDetails());
                        } else {
                            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                        }
                    }
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Total hours: " + returnTotalHours());
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 3);
    }
}

   

